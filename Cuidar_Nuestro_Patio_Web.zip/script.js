
function respuesta(tipo){
document.getElementById('resultado').innerText =
tipo==='correcto' ? '¡Correcto!' : 'Inténtalo nuevamente';
}
